<div class="card p-0 bg-white">
    <div class="card-header bg-white">
        <h5 class="text-uppercase mt-2 font-weight-bold">Input Barang</h5>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-12 col-md-6 mx-auto mx-md-0">
                <form action="<?php echo e(route('store.temporary')); ?>" method="POST" id="form">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="teknisi" class="col-sm-3 col-form-label">Teknisi</label>
                        <div class="col-sm-8">
                            <select name="teknisi" id="teknisi"
                                class="form-control form-control-sm <?php $__errorArgs = ['teknisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <option value="">Pilih Teknisi</option>
                                <?php $__currentLoopData = $teknisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data->id); ?>"
                                        <?php echo e($data->id == (old('teknisi') ?: $lastTeknisi) ? 'selected' : ''); ?>>
                                        <?php echo e($data->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['teknisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="barang" class="col-sm-3 col-form-label">Barang</label>
                        <div class="col-sm-8">

                            <div class="input-group">
                                <input type="text" name="barang" id="barang" required autofocus
                                    class="form-control text-center <?php $__errorArgs = ['barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    value="<?php echo e(old('barang')); ?>" autocomplete="">
                                <button type="button" id="selectBarang" data-bs-target="#modalBarang"
                                    data-bs-toggle="modal" class="input-group-text btn btn-primary"
                                    style="background-color: #1c2260">Pilih Barang</button>
                                <?php $__errorArgs = ['barang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="id_order" class="col-sm-3 col-form-label">ID Order</label>
                        <div class="col-sm-8">
                            <input type="text" name="id_order" id="id_order"
                                class="form-control form-control-sm text-center <?php $__errorArgs = ['id_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(old('id_order') ?: $lastIdOrder); ?>" placeholder="KBH-9358-04" required>
                            <?php $__errorArgs = ['id_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row col-md-12 text-right">
                        <div class="col-sm-12">
                            <button type="submit" class="btn btn-primary " id="btn-input"
                                style="background-color: #5f64f4">Input</button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="col-12 col-md-6 mt-3 mt-md-0 mx-auto mx-md-0">
                <div class="card">
                    <div class="card-body" style="background-color:#e8e8f3; ">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="row mb-3">
                                    <div class="col-5 font-weight-bold pt-2">Teknisi</div>
                                    <div class="col-1 pt-2">:</div>
                                    <div class="col-6 pt-2" id="teknisiName">-</div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-5 font-weight-bold pt-2">Id Teknisi</div>
                                    <div class="col-1 pt-2">:</div>
                                    <div class="col-6 pt-2" id="teknisiId">-</div>
                                </div>
                                <div class="row mb-3">
                                    <div class="col-5 font-weight-bold pt-2">Status Target</div>
                                    <div class="col-1 pt-2">:</div>
                                    <div class="col-6 pt-2 font-weight-bold" id="statusTarget">-</div>
                                </div>
                            </div>

                            <div class="col-md-2 col-12" style="margin:auto">
                                <div class="p-1 text-center"
                                    style="margin: auto; background-color: #d4d4e8; border-radius: 20%; border: 1px solid black;">
                                    <h6 class="font-weight-bold">POINT</h6>
                                    <h4 class="font-weight-bold" style="color:#202dbd" id="point">0</h4>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Project\Website\DASER.IM\Daser\resources\views/pages/service/inputBarang.blade.php ENDPATH**/ ?>