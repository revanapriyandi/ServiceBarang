<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><strong>Teknisi</strong></h1>
        </div>

        <div class="row">
            <div class="card px-0">
                <div class="card-header">
                    <div class="text-dark font-weight-bold">Data Teknisi</div>
                </div>
                <div class="card-body">
                    <?php if (isset($component)) { $__componentOriginalb5e767ad160784309dfcad41e788743b = $component; } ?>
<?php $component = App\View\Components\Alert::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Alert::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb5e767ad160784309dfcad41e788743b)): ?>
<?php $component = $__componentOriginalb5e767ad160784309dfcad41e788743b; ?>
<?php unset($__componentOriginalb5e767ad160784309dfcad41e788743b); ?>
<?php endif; ?>

                    <a href="javascript:;" id="add" class="btn btn-primary mt-3 mb-4">Tambah data</a>
                    <div class="table-responsive">
                        <table class="table table-striped dataTable">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Id Teknisi</th>
                                    <th>Nama </th>
                                    <th>Email</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $teknisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($data->uid); ?></td>
                                        <td><?php echo e($data->name); ?></td>
                                        <td><?php echo e($data->email); ?></td>
                                        <td>
                                            <a href="javascript:;" data-id="<?php echo e($data->id); ?>"
                                                class="btn btn-warning edit btn-sm">Edit</a>
                                            <a href="javascript:;"
                                                onclick="event.preventDefault(); confirmDelete(<?php echo e($data->id); ?>);"
                                                class="btn btn-danger btn-sm">Delete</a>

                                            <form id="delete-form-<?php echo e($data->id); ?>"
                                                action="<?php echo e(route('teknisi.destroy', $data->id)); ?>" method="POST"
                                                style="display: none;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modal" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="form" action="/teknisi" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="post">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
                        <button class="close" onclick="$('#modal').modal('hide');" type="button" data-dismiss="modal"
                            aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div id="form-errors"></div>
                        <div class="form-outline mb-3">
                            <label for="idteknisi" class="col-form-label"><?php echo e(__('Id Teknisi')); ?><span
                                    class="text-danger">*</span></label>

                            <input id="idteknisi" type="text"
                                class="form-control <?php $__errorArgs = ['idteknisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="idteknisi" required
                                autofocus>

                            <?php $__errorArgs = ['idteknisi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-outline mb-3">
                            <label for="name" class="col-form-label"><?php echo e(__('Nama Teknisi')); ?><span
                                    class="text-red">*</span></label>

                            <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="name" required autocomplete="false" value="<?php echo e(old('name')); ?>">

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-outline mb-3">
                            <label for="email" class="col-form-label"><?php echo e(__('Email')); ?><span
                                    class="text-red">*</span></label>

                            <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="email" required autocomplete="false" value="<?php echo e(old('email')); ?>">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button"
                            onclick="$('#modal').modal('hide');">Cancel</button>
                        <button class="btn btn-primary" type="submit">Simpan</button>
                    </div>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        let table = new DataTable('.table', {
            paging: true,
            lengthChange: true,
            searching: true,
            ordering: true,
            info: true,
            autoWidth: true,
            responsive: true,
        });

        function confirmDelete(id) {
            if (confirm('Are you sure you want to delete this item?')) {
                document.getElementById('delete-form-' + id).submit();
            }
        }

        $(document).ready(function() {
            $('#add').click(function() {
                $('#modal .modal-title').text('Tambah Data');
                $('#modal input[name="_method"]').val('post');
                $('#form').attr('action', '<?php echo e(route('teknisi.store')); ?>');
                $('#modal').modal('show');
            });

            $(document).on('click', '.edit', function() {
                var id = $(this).data('id');
                $.get('<?php echo e(route('teknisi.show', 'idteknisi')); ?>'.replace(
                    'idteknisi', id), function(data) {
                    // Set the modal to the state for editing data
                    $('#modal .modal-title').text('Edit Data');
                    $('#modal input[name="_method"]').val('put');
                    $('#form').attr('action', '<?php echo e(route('teknisi.update', 'idteknisi')); ?>'.replace(
                        'idteknisi', id));
                    $('#modal input[name="idteknisi"]').val(data.uid);
                    $('#modal input[name="name"]').val(data.name);
                    $('#modal input[name="email"]').val(data.email);
                    $('#modal').modal('show');
                });
            });

            $('#modal').on('hidden.bs.modal', function(e) {
                $('#form')[0].reset();
                $('#form-errors').empty();
                $('#form').attr('action', '<?php echo e(route('teknisi.store')); ?>');
                $('#modal input[name="_method"]').val('post');
                $('#modal .modal-title').text('Tambah Data');
            });

            $('#form').on('submit', function(e) {
                e.preventDefault();

                var url = $(this).attr('action');
                var method = $('#modal input[name="_method"]').val();
                var data = $(this).serialize();

                $.ajax({
                    url: url,
                    type: method,
                    data: data,
                    success: function(response) {
                        $('#modal').modal('hide');
                        location.reload()
                    },
                    error: function(jqXHR, textStatus, errorThrown) {
                        if (jqXHR.status === 422) {
                            var errors = jqXHR.responseJSON.errors;
                            var error_message = '';

                            $.each(errors, function(key, value) {
                                error_message += '<p>' + value + '</p>';
                            });

                            $('#form-errors').html('<div class="alert alert-danger">' +
                                error_message + '</div>');
                        }
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Website\DASER.IM\Daser\resources\views/pages/teknisi/view.blade.php ENDPATH**/ ?>