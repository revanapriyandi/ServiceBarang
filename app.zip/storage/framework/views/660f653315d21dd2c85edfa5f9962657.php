<?php
    $dataTemporary = session('data_temporary', []);
    $lastIdOrder = $dataTemporary ? end($dataTemporary)['id_order'] : '';
    $lastTeknisi = $dataTemporary ? end($dataTemporary)['teknisi'] : '';
    $point = 0;
?>


<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('pages.service.inputBarang', ['lastIdOrder' => $lastIdOrder], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('pages.service.table', [
            'dataTemporary' => $dataTemporary,
            'point' => $point,
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('modal'); ?>
    <?php echo $__env->make('pages.service.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/@ttskch/select2-bootstrap4-theme@x.x.x/dist/select2-bootstrap4.min.css">
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
    <?php echo $__env->make('pages.service.script-input', ['teknisis' => $teknisi, 'barangs' => $barang], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Project\Website\DASER.IM\Daser\resources\views/pages/service/input-barang.blade.php ENDPATH**/ ?>