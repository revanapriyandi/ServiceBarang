<div class="modal fade" id="modalBarang" aria-hidden="true" aria-labelledby="modalBarangLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="modalBarangLabel">Data Barang</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-striped" id="tableBarang">
                    <thead>
                        <tr>
                            <th>ID Barang</th>
                            <th>Nama Barang</th>
                            <th>Point</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $barangs = \App\Models\Barang::all();
                        ?>
                        <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="font-weight-bold">
                                <td><?php echo e($d->uid); ?></td>
                                <td><?php echo e($d->name); ?></td>
                                <td><?php echo e($d->point); ?></td>
                                <td>
                                    <button type="button" class="btn btn-primary btn-sm" data-bs-dismiss="modal"
                                        onclick="selectBarang('<?php echo e($d->uid); ?>', '<?php echo e($d->name); ?>')">Pilih</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" data-bs-dismiss="modal" aria-label="Close">Close</button>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\Project\Website\DASER.IM\Daser\resources\views/pages/service/modal.blade.php ENDPATH**/ ?>